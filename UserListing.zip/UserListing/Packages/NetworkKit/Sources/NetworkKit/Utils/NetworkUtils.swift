//
//  NetworkUtils.swift
//

import Foundation
import DomainKit

public class NetworkUtils {
    public class func toDomainModel<U: BaseModel>(result: Result<U, RequestError>) -> Result<U.T, RequestError> {
        switch result {
        case .success(let dto):
            return .success(dto.toDomainModel())
        case .failure(let error):
            return .failure(error)
        }
    }
    
    public class func toDomainModels<U: BaseModel>(result: Result<Array<U>, RequestError>) -> Result<Array<U.T>, RequestError> {
        switch result {
        case .success(let dtos):
            var domainModels: Array<U.T> = []
            for dto in dtos {
                let result = NetworkUtils.toDomainModel(result: .success(dto))
                switch result {
                case .success(let domainModel):
                    domainModels.append(domainModel)
                case .failure(let error):
                    print(error)
                }
            }
            return .success(domainModels)
        case .failure(let error):
            return .failure(error)
        }
    }
}


