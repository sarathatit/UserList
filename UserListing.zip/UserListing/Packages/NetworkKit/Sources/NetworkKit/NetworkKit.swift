public struct NetworkKit {
    public private(set) var text = "Hello, World!"

    public init() {
    }
}
