//
//  HTTPClient.swift
//  

import Foundation
import Alamofire
import DomainKit

public protocol HTTPClient {
    func sendRequest<T: Decodable>(endpoint: Endpoint, responseModel: T.Type) async -> Result<T, RequestError>
}

extension HTTPClient {
    
    public func sendRequest<T: Decodable>(endpoint: Endpoint, responseModel: T.Type) async -> Result<T, RequestError> {
        
        let path = endpoint.path.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        guard let url = URL(string: endpoint.baseURL + path) else {
            return .failure(RequestError.defaultRequestError())
        }
        let headers = getRequestHeader(forEndpoint: endpoint)
        
        return await withCheckedContinuation { continuation in
            API.shared.sessionManager.request(url, method: HTTPMethod(rawValue: endpoint.method.rawValue), parameters: endpoint.body, encoding: endpoint.encodingType, headers: headers).responseData { responseData in
                
                guard let response = responseData.data else {
                    //Handel empty responseurl
                    if isArray(type: T.self) {
                        let emptyResponse = "[]"
                        guard let jsonData = emptyResponse.data(using: .utf8),
                                let emptyArray: T = try? JSONDecoder().decode(T.self, from: jsonData) else {
                            continuation.resume(returning: .failure(RequestError.defaultRequestError()))
                            return;
                        }
                        
                        continuation.resume(returning: .success(emptyArray))
                        return
                    }
                    else {
                        let emptyResponse = "{}"
                        guard let jsonData = emptyResponse.data(using: .utf8) else {
                            continuation.resume(returning: .failure(RequestError.defaultRequestError()))
                            return;
                        }
                        
                        do {
                            let emptyObject: T = try JSONDecoder().decode(T.self, from: jsonData)
                            continuation.resume(returning: .success(emptyObject))
                            return
                        }
                        catch {
                            if T.self == Bool.self {
                                continuation.resume(returning: .success(false as! T))
                                return;
                            }
                            else {
                                continuation.resume(returning: .failure(RequestError.defaultRequestError()))
                                return
                            }
                        }
                    }
                }
                
                // Error Case
                // TODO: Need to check Error response
                if let errorResponse = try? JSONDecoder().decode(APIError.self, from: response) {
                    if let errorMsg = errorResponse.error, !errorMsg.isEmpty {
                        continuation.resume(returning: .failure(RequestError(title: errorMsg, description: errorResponse.error_description ?? "Unexpected Result", code: 0)))
                        return;
                    }
                }
                
                // Succes Case
//                let json = try! JSONSerialization.jsonObject(with: response, options: .allowFragments)
//                print(json)
                if let successResponse = try? JSONDecoder().decode(T.self, from: response) {
                    continuation.resume(returning: .success(successResponse))
                    return;
                }
                
                // Default Error
                continuation.resume(returning: .failure(RequestError.defaultRequestError()))
                return;
            }
        }
        
    }
    
    /// To get the request header for the endpoint
    func getRequestHeader(forEndpoint endpoint: Endpoint) -> HTTPHeaders {
        var headers = HTTPHeaders(endpoint.header)
        headers[HeaderKey.AUTHORIZATION] = "\(HeaderKey.BEARER) " + "8a20aeffa7c491da4493c204b44dc5caaa3315793661fdeba1903336f0b94266"
        print("Headers", headers)
                return headers
    }
}

protocol AnyTypeOfArray {}
extension Array: AnyTypeOfArray {}
extension NSArray: AnyTypeOfArray {}

func isArray<T>(type: T.Type) -> Bool {
    return T.self is AnyTypeOfArray.Type
}
