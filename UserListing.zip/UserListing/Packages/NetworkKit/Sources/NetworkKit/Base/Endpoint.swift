//
//  Endpoint.swift
//  

import Foundation
import Alamofire
import DomainKit

public protocol Endpoint {
    var baseURL: String { get }
    var path: String { get }
    var method: RequestMethod { get }
    var header: [String: String] { get }
    var body: [String: Any] { get }
    var encodingType: ParameterEncoding { get }
}


extension Endpoint {
    
    public var baseURL: String {
        return AppConfig.baseURL
    }
    
    public var header: [String: String] {
        return [HeaderKey.CONTENT_TYPE: "application/json"]
    }
    
    public var encodingType: ParameterEncoding {
        return JSONEncoding()
    }
    
    public var body: [String: Any] {
        return [:]
    }
}


public enum RequestMethod: String {
    case delete = "DELETE"
    case get = "GET"
    case patch = "PATCH"
    case post = "POST"
    case put = "PUT"
}

struct HeaderKey {
    private init() {}
    public static let CONTENT_TYPE = "Content-Type"
    public static let AUTHORIZATION = "Authorization"
    public static let BEARER = "Bearer"
    public static let VAL_CONTENT_TYPE = "application/x-www-form-urlencoded"
}
