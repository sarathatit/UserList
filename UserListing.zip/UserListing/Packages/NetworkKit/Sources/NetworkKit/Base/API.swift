//
//  API.swift
//  

import Foundation
import Alamofire


public class API {
    public  static let shared = API()
    private init() { }
    
    lazy var sessionManager: Session = {
      let configuration = URLSessionConfiguration.af.default
        configuration.headers = [:]
        configuration.timeoutIntervalForRequest = 60
        configuration.timeoutIntervalForResource = 60
        return Session(configuration: configuration)
    }()
}
