//
//  NetworkReachability.swift
//  

import Foundation
import Alamofire
import RxSwift
import RxRelay

public class NetworkReachability {
   
    private let networkReachabilitySubject = PublishSubject<Bool>()
    let reachabilityManager = NetworkReachabilityManager(host: "www.google.com")
    
    public init() {
        startNetworkMonitoring()
    }
        
    func startNetworkMonitoring() {
      reachabilityManager?.startListening { [weak self] (status) in
        switch status {
        case .notReachable:
            self?.networkReachabilitySubject.onNext(false)
        case .reachable(.cellular), .reachable(.ethernetOrWiFi):
            self?.networkReachabilitySubject.onNext(true)
        case .unknown:
            self?.networkReachabilitySubject.onNext(false)
        }
      }
    }
    
    func isReachable() -> Bool {
        return reachabilityManager?.isReachable ?? false
    }

    
    func observeNetworkChanges() -> Observable<Bool> {
        return networkReachabilitySubject
    }

}
