//
//  APIError.swift
//  

import Foundation

public class APIError: Error, Decodable {
    public init(error: String? = nil, error_description: String? = nil, code: String? = nil) {
        self.error = error
        self.error_description = error_description
        self.code = code
    }
    
    public var error: String?
    public var error_description: String?
    public var code: String?
}

