//
//  File.swift
//  

import Foundation
public struct CommonResponse {
    
    public let message: String
    
    public init(message: String) {
        self.message = message
    }
}
