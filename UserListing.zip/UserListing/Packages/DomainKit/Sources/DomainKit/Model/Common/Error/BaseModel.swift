//
//  BaseModel.swift
//  

import Foundation

public protocol BaseModel {
    associatedtype T
    func toDomainModel() -> T
}

