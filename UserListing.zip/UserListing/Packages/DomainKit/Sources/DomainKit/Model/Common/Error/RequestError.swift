//
//  RequestError.swift
//  
//

import Foundation

protocol RequestErrorProtocol: LocalizedError {

    var title: String? { get }
    var code: Int { get }
}

public struct RequestError: RequestErrorProtocol {

    private (set) public var title: String?
    private (set) public var code: Int
    public var errorDescription: String? { return _description }
    public var failureReason: String? { return _description }

    private var _description: String

    public init(title: String? = nil, description: String, code: Int) {
        self.title = title ?? "Error"
        self._description = description
        self.code = code
    }
}

extension RequestError {
    
    public static func defaultRequestError() -> RequestError {
        return RequestError(title: "Error", description: "Unexpected Result", code: RequestErrorCode.UNEXPECTED_ERROR_CODE.rawValue)
    }
}

public enum RequestErrorCode: Int {
    case UNEXPECTED_ERROR_CODE = 10005
}
