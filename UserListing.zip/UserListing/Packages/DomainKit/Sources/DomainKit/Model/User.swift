//
//  User.swift
//

import Foundation

public struct User {
    public let name: String
    public let gender: String
    public let status: String
    public let id: Int
    public let email: String
    
    public init(name: String, gender: String, status: String, id: Int, email: String) {
        self.name = name
        self.gender = gender
        self.status = status
        self.id = id
        self.email = email
    }
}
