public struct DomainKit {
    public private(set) var text = "Hello, World!"

    public init() {
    }
}
