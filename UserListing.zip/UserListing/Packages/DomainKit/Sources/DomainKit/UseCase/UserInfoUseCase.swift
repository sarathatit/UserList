//
//  UserInfoCase.swift
//  

import Foundation

public protocol UserInfoUseCase {
    func getUserList() async -> Result<[User], RequestError>
    func updateUserList(name: String, email: String, id: Int, status: String, gender: String) async -> Result<User, RequestError>
    func deleteUserList(id: Int) async -> Result<CommonResponse, RequestError>
    func getUserDetails(id: Int) async -> Result<User, RequestError>
}
