//
//  AppConfig.swift
//  

import Foundation

public enum AppConfig {
    
    // MARK: - Keys
    enum Keys {
        enum Plist {
            static let baseURL = "BASE_URL"
        }
    }
    
    // MARK: - Plist
    private static let infoDictionary: [String: Any] = {
        guard let dict = Bundle.main.infoDictionary else {
            fatalError("Plist file not found")
        }
        return dict
    }()
    
    // MARK: - Plist values
    public static let baseURL: String = {
        return "https://gorest.co.in/public/v2"
    }()
    
    public static let appID: String = {
        return "397d2e857f475f9884ff9702b3b1bc2a"
    }()
}

extension String {
    func trim() -> String {
        return self.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
    }
}
