//
//  DIExtensions.swift
//  

import DataKit
import DomainKit

public extension DependencyContainer {
    
    static var user = module {
        factory { UserUseCase(userServicable: UserService()) as UserInfoUseCase }
    }
}
