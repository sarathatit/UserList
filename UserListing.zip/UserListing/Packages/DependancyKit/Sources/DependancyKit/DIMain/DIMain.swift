//
//  DIMain.swift
//  

import Foundation

public class DIMain {
    
    public init() {
    }
    
    public func initializeDI() {
        DependencyContainer.defined(by: modules(makeChildren: {
            DependencyContainer.user
        }))
    }
}
