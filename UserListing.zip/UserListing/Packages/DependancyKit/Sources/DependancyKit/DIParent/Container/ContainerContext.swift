

/// Exposes the `DependencyContainer` through for instance `AppDelegate`.
public protocol ContainerContext {
    var container: DependencyContainer { get }
}
