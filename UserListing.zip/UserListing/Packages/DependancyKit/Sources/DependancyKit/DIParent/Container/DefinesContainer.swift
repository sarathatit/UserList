

/// Exposes the `DependencyContainer` through for instance `AppDelegate`.
public protocol DefinesContainer {
    var container: DependencyContainer { get }
}
