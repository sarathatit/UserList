//
//  HomeDTO.swift
//

import Foundation
import DomainKit

struct UserDTO:BaseModel, Decodable {
    typealias T = User
    
    let name: String?
    let email: String?
    let id: Int?
    let status: String?
    let gender: String?
    
    enum CodingKeys: String, CodingKey {
        case name = "name"
        case email = "email"
        case id = "id"
        case status = "status"
        case gender = "gender"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        name = try values.decodeIfPresent(String.self, forKey: .name)
        email = try values.decodeIfPresent(String.self, forKey: .email)
        id = try values.decodeIfPresent(Int.self, forKey: .id)
        status = try values.decodeIfPresent(String.self, forKey: .status)
        gender = try values.decodeIfPresent(String.self, forKey: .gender)
    }
    
    func toDomainModel() -> User {
        User(name: name ?? "", gender: gender ?? "", status: status ?? "", id: id ?? 1, email: email ?? "")
    }
}

struct ResponseDTO: BaseModel, Decodable {
    typealias T = CommonResponse
    
    let responseMessage: String?
    
    enum CodingKeys: String, CodingKey {
        case responseMessage = "message"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        responseMessage = try values.decodeIfPresent(String.self, forKey: .responseMessage)
    }
    
    func toDomainModel() -> CommonResponse {
        return CommonResponse( message: responseMessage ?? "")
    }
}
