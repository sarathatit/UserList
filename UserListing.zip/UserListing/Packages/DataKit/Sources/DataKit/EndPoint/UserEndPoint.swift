//
//  UserEndPoint.swift
//  

import Foundation
import NetworkKit
import DomainKit
import Alamofire

enum UserURL: String{
    case getUserList = "/users"
    case deleteUserList = "/todos/"
    case getUserDetail = "/users/"
}

public enum UserEndPoint {
    case getUserList
    case deleteUserList(id: String)
    case updateUserList(name: String, id: String, email: String, gender: String, status: String)
    case getUserDetail(id: String)
}

extension UserEndPoint:Endpoint {
    public var baseURL: String {
        return AppConfig.baseURL
    }
    
    public var appId: String {
        return AppConfig.appID
    }

    public var path: String {
        switch self {
        case .getUserList:
            return UserURL.getUserList.rawValue
        case .deleteUserList(let id):
            return UserURL.deleteUserList.rawValue + id
        case .updateUserList(_, let id, _, _, _):
            return UserURL.getUserDetail.rawValue + id
        case .getUserDetail(let id):
            return UserURL.getUserDetail.rawValue + id
        }
    }
    
    public var method: RequestMethod {
        switch self {
        case .getUserList:
            return .get
        case .deleteUserList:
            return .delete
        case .updateUserList:
            return .put
        case .getUserDetail:
            return .get
        }
    }
    
    public var body: [String : Any] {
        switch self {
        case .getUserList, .deleteUserList, .getUserDetail:
            return [:]
        case .updateUserList(let name, _, let email, let gender, let status):
            return [
                "name": name,
                "email": email,
                "gender": gender,
                "status": status]
        }
    }
            
    public var encodingType: ParameterEncoding {
        switch self {
        case .getUserList, .deleteUserList, .getUserDetail:
            return URLEncoding.default
        case .updateUserList:
            return JSONEncoding()
        }
    }
}
