//
//  UserUseCase.swift
//  

import Foundation
import DomainKit

public class UserUseCase: UserInfoUseCase {
    
    // MARK: - Properties
    private let userServicable: UserServiceable
    
    // MARK: - Init
    public init(userServicable: UserServiceable) {
        self.userServicable = userServicable
    }
    
    public func getUserList() async -> Result<[User], RequestError> {
        let result =  await userServicable.getUserList()
          switch result {
          case .success(let userData):
              return .success(userData)
          case .failure(let error):
              return .failure(error)
          }
    }
    
    public func updateUserList(name: String, email: String, id: Int, status: String, gender: String) async -> Result<User, RequestError> {
        let result =  await userServicable.updateUserList(name: name, email: email, id: id, status: status, gender: gender)
          switch result {
          case .success(let userData):
              return .success(userData)
          case .failure(let error):
              return .failure(error)
          }
    }
    
    public func deleteUserList(id: Int) async -> Result<CommonResponse, RequestError> {
        let result =  await userServicable.deleteUserList(id: id)
          switch result {
          case .success(let userData):
              return .success(userData)
          case .failure(let error):
              return .failure(error)
          }
    }
    
    public func getUserDetails(id: Int) async -> Result<User, RequestError> {
        let result =  await userServicable.getUserDetails(id: id)
          switch result {
          case .success(let userData):
              return .success(userData)
          case .failure(let error):
              return .failure(error)
          }
    }
    
}
