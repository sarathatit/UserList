//
//  HomeUseCase.swift
//  

import Foundation
import NetworkKit
import DomainKit

public protocol UserServiceable {
    func getUserList() async -> Result<[User], RequestError>
    func updateUserList(name: String, email: String, id: Int, status: String, gender: String) async -> Result<User, RequestError>
    func deleteUserList(id: Int) async -> Result<CommonResponse, RequestError>
    func getUserDetails(id: Int) async -> Result<User, RequestError>
}

public struct UserService: HTTPClient, UserServiceable {
        
    // MARK: - init method
    public init() {
    }
    
    public func getUserDetails(id: Int) async -> Result<User, RequestError> {
        let result = await sendRequest(endpoint: UserEndPoint.getUserDetail(id: String(id)), responseModel: UserDTO.self)
        let domainResult = NetworkUtils.toDomainModel(result: result)
        return domainResult
    }
    
    public func getUserList() async -> Result<[User], RequestError> {
        let result = await sendRequest(endpoint: UserEndPoint.getUserList, responseModel: [UserDTO].self)
        let domainResult = NetworkUtils.toDomainModels(result: result)
        return domainResult
    }
    
    public func updateUserList(name: String, email: String, id: Int, status: String, gender: String) async -> Result<User, RequestError> {
        let result = await sendRequest(endpoint: UserEndPoint.updateUserList(name: name, id: String(id), email: email, gender: gender, status: status), responseModel: UserDTO.self)
        let domainResult = NetworkUtils.toDomainModel(result: result)
        return domainResult
    }
    
    public func deleteUserList(id: Int) async -> Result<CommonResponse, RequestError> {
        let result = await sendRequest(endpoint: UserEndPoint.deleteUserList(id: String(id)), responseModel: ResponseDTO.self)
        let domainResult = NetworkUtils.toDomainModel(result: result)
        return domainResult
    }
}
