//
//  UserListViewController.swift
//  UserListing
//

import UIKit
import RxSwift
import RxCocoa
import DomainKit

class UserListViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    var viewModel: UserListViewModel?
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel = UserListViewModel()
        configureTableview()
        subscribe()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        viewModel?.getUserList()
    }
    
    private func configureTableview() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .none
        tableView.register(UserCardTableViewCell.nib(),
                                forCellReuseIdentifier: UserCardTableViewCell.reuseIdentifier())
    }
    
    private func subscribe() {
        viewModel?.dataSubject.observe(on: MainScheduler.instance).subscribe { [weak self] (_) in
            guard let strongSelf = self else { return }
            strongSelf.tableView.reloadData()
        }.disposed(by: disposeBag)
    }
}

extension UserListViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let count = viewModel?.userList.count else { return 0}
        return count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: UserCardTableViewCell = tableView.dequeueReusableCell(for: indexPath)
        if let user = viewModel?.userList[indexPath.row] {
            cell.configureCells(user: user)
        }
        cell.tag = indexPath.row
        cell.delegate = self
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let coordinator: UserDetailViewCoordinator = CoordinatorFactory.create(with: self.navigationController!, withType: .userDetail, withValues: viewModel?.userList[indexPath.row].id ?? 1) as? UserDetailViewCoordinator  else { return }
        coordinator.start(animated: false)
    }
}
extension UserListViewController: UserCardDelegate {
    func didDeleteTap(index: Int) {
        if let id = viewModel?.userList[index].id {
            viewModel?.deleteUserList(id: id)
        }
    }
}
