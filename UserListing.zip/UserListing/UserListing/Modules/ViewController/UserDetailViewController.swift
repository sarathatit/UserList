//
//  UserDetailViewController.swift
//  UserListing
//

import UIKit
import RxSwift
import RxCocoa
import DomainKit

class UserDetailViewController: UIViewController {

    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var email: UITextField!

    var userDetailViewModel: UserDetailViewModel?
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userDetailViewModel?.getUserDetail()
        subscribe()
    }

    private func subscribe() {
        userDetailViewModel?.dataSubject.observe(on: MainScheduler.instance).subscribe { [weak self] (_) in
            guard let strongSelf = self else { return }
            strongSelf.name.text = strongSelf.userDetailViewModel?.user?.name ?? ""
            strongSelf.email.text = strongSelf.userDetailViewModel?.user?.email ?? ""
        }.disposed(by: disposeBag)
    }
    
    @IBAction func updateTapped(_ sender: Any) {
        userDetailViewModel?.updateUserDetail(name: name.text ?? "", email:email.text ?? "", id: userDetailViewModel?.userId ?? 0, status: userDetailViewModel?.user?.status ?? "", gender:userDetailViewModel?.user?.gender ?? "")
    }
    
}
