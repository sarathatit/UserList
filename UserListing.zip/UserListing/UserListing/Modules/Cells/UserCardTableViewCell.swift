//
//  UserCardTableViewCell.swift
//  UserListing
//

import UIKit
import DomainKit

protocol UserCardDelegate: AnyObject {
    func didDeleteTap(index: Int)
}

class UserCardTableViewCell: UITableViewCell {

    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var gender: UILabel!
    @IBOutlet weak var status: UILabel!
    @IBOutlet weak var email: UILabel!
    weak var delegate: UserCardDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
   
    func configureCells(user: User) {
        self.name.text = "Name: \(user.name)"
        self.gender.text = "Gender: \(user.gender)"
        self.status.text = "Status: \(user.status)"
        self.email.text = "Email: \(user.email)"
        
    }
    
    @IBAction func deleteTapped(_ sender: Any) {
        delegate?.didDeleteTap(index: self.tag)
    }
}
