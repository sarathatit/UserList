//
//  UITableViewCell+Extension.swift
//

import Foundation
import UIKit

extension UITableViewCell {
    class func reuseIdentifier() -> String {
        return String(describing: self)
    }
    class func nib() -> UINib {
        return UINib(nibName: String(describing: self), bundle: nil)
    }
    
    func setCellSelectionColor(color: UIColor = .black) {
        let backgroundView = UIView()
        backgroundView.backgroundColor = color
        selectedBackgroundView = backgroundView
    }
}
// MARK: - NibNameProvider
protocol NibNameProvider {
    static var uiNibName: String { get }
}

// MARK: - SegueIdentifierProvider
protocol SegueIdentifierProvider {
    var segueIdentifier: String { get }
}
// MARK: - StaticReuseIdentifierProvider
protocol StaticReuseIdentifierProvider {
    static var reuseIdentifier: String { get }
}

extension UIView: NibNameProvider {
    static var uiNibName: String {
        return String(describing: self).components(separatedBy: ".").last!
    }
}
extension UITableView {
    func registerCell<T: NibNameProvider & StaticReuseIdentifierProvider>(_ cellType: T.Type) {
        self.register(UINib(nibName: cellType.uiNibName, bundle: nil),
                      forCellReuseIdentifier: cellType.reuseIdentifier)
    }
    
    func registerHeaderFooter<T: NibNameProvider & StaticReuseIdentifierProvider>(_ headerType: T.Type) {
        self.register(UINib(nibName: headerType.uiNibName, bundle: nil),
                      forHeaderFooterViewReuseIdentifier: headerType.reuseIdentifier)
    }
    
    func dequeueCell<T: NibNameProvider & StaticReuseIdentifierProvider>(_ headerType: T.Type, for indexPath: IndexPath) -> T {
        // swiftlint:disable:next force_cast
        let cell = self.dequeueReusableCell(withIdentifier: headerType.reuseIdentifier,
                                            for: indexPath) as! T
        return cell
    }
    
    func dequeueHeaderFooter<T: NibNameProvider & StaticReuseIdentifierProvider>(_ headerType: T.Type) -> T {
        let view = self.dequeueReusableHeaderFooterView(withIdentifier: headerType.reuseIdentifier) as! T
        return view
    }
}

extension UIView: StaticReuseIdentifierProvider {
    static var reuseIdentifier: String {
        return String(describing: self).components(separatedBy: ".").last!
    }
}
