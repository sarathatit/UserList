//
//  UITableviewCell+Extension.swift
//  UserListing
//

import UIKit
import Foundation

extension UITableView {
    
    /**
     Configure table view.
     
     To set estimatedRowHeight.
     
     - parameter estimatedRowsHeight: Default is 120.
     */
    
    func configureTableView(estimatedRowsHeight: CGFloat = 120.0) {
        estimatedRowHeight = estimatedRowsHeight
        rowHeight = UITableView.automaticDimension
        
    }
    
    func addEmptyFooter(footerHeight: CGFloat? = nil) {
        if footerHeight != nil {
            tableFooterView = UIView(frame: CGRect(x: 0, y: 0, width: frame.size.width, height: footerHeight!))
        } else {
            tableFooterView = UIView()
        }
    }
    func addEmptyHeader(headreHeight: CGFloat? = nil) {
        if headreHeight != nil {
            tableHeaderView = UIView(frame: CGRect(x: 0, y: 0, width: frame.size.width, height: headreHeight!))
        } else {
            tableHeaderView = UIView()
        }
    }
    
    /**
     Dequeue Reusable Cell.
     
     Returns a generic <T> reusable table-view cell object for the specified reuse identifier and adds it to the table.
     
     - parameter indexPath: The index path specifying the location of the cell
     - returns: Returns a reusable table-view cell object for the specified reuse identifier and adds it to the table.
     */
    func dequeueReusableCell<T: UITableViewCell>(for indexPath: IndexPath) -> T {
        guard let cell = dequeueReusableCell(withIdentifier: T.storyboardIdentifier, for: indexPath) as? T else {
            fatalError("Could not find table view cell with identifier \(T.storyboardIdentifier)")
        }
        return cell
    }
    
    /**
     Cell for rowIndex.
     
     Returns a generic <T> table cell at the specified index path.
     
     - parameter indexPath:The index path locating the row in the table view.
     - returns: Returns the table cell at the specified index path..
     */
    
    func cellForRow<T: UITableViewCell>(at indexPath: IndexPath) -> T? {
        guard let cell = cellForRow(at: indexPath) as? T else {
            return nil
        }
        return cell
    }
    
    /**
     Get Visible Cell.
     
     Returns a generic <T> current visible table view cell at the specified row and section.
     
     - parameter indexPath:The current visible cell indexPath.
     - returns: Returns the visible table cell at the specified index path..
     */
    
    func getVisibleCell<T: UITableViewCell>(forIndexPath indexPath: IndexPath) -> T? {
        if let indexPathsForVisibleRows = indexPathsForVisibleRows {
            if indexPathsForVisibleRows.contains(indexPath) {
                guard let cell = cellForRow(at: indexPath) as? T else {
                    return nil
                }
                return cell
            }
        }
        return nil
    }
    
    func indexPathForLastRow() -> IndexPath {
        let indexPath = IndexPath(row: numberOfRows(inSection: numberOfSections - 1) - 1, section: numberOfSections - 1)
        return indexPath
    }
    
    func scrollToIndex(idx: Int, animated: Bool = true) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.01) {
            if self.numberOfRows(inSection: 0) > 0 {
                let indexPath = IndexPath(row: idx, section: 0)
                self.scrollToRow(at: indexPath, at: .top, animated: animated)
            }
        }
    }
    
    func scrollToTop(animated: Bool = true) {
        guard self.numberOfSections > 0 else {
            return
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.01) {
            if self.numberOfRows(inSection: 0) > 0 {
                let indexPath = IndexPath(row: 0, section: 0)
                self.scrollToRow(at: indexPath, at: .top, animated: animated)
            }
        }
    }
    
    func tableViewScrollToBottom(animated: Bool = true) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.01) {
            let numberOfSections = self.numberOfSections
            let numberOfRows = self.numberOfRows(inSection: numberOfSections-1)
            if numberOfRows > 0 {
                let indexPath = IndexPath(row: numberOfRows-1, section: numberOfSections-1)
                self.scrollToRow(at: indexPath, at: .bottom, animated: animated)
            }
        }
    }
    
    func deselectRow() {
        if let indexPath = indexPathForSelectedRow {
            deselectRow(at: indexPath, animated: true)
        }
    }
    
    /**
     Get TableviewCell indexPathForView
     */
    func indexPathForView(_ view: UIView) -> IndexPath? {
        let tableViewTouchPoint:CGPoint = view.convert(CGPoint.zero, to:self)
        let indexPath = self.indexPathForRow(at: tableViewTouchPoint)
        return indexPath
    }
    
    func reloadWithFadeAnimation() {
        UIView.transition(with: self,
                          duration: 0.2,
                          options: .transitionCrossDissolve,
                          animations: { () -> Void in
            self.reloadData()
        },completion: nil)
    }
    
    func restore() {
        self.backgroundView = nil
        self.separatorStyle = .singleLine
    }
}

extension UIScrollView {
    func stopPullToRefresh() {
        if let refreshControl = viewWithTag(-111) as? UIRefreshControl {
            if refreshControl.isRefreshing {
                refreshControl.endRefreshing()
            }
        }
    }
}
