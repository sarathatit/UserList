//
//  UserListViewModel.swift
//  UserListing
//

import Foundation
import DomainKit
import DependancyKit
import RxSwift
import RxCocoa
import DomainKit

class UserListViewModel {
    private let userUseCase: UserInfoUseCase
    var dataSubject = PublishSubject<Void>()
    var userList : [User] = []
    
    init(userUseCase: UserInfoUseCase = resolve()) {
        self.userUseCase = userUseCase
    }
    
    
    func getUserList() {
        Task(priority: .userInitiated) { [weak self] in
            guard let strongSelf = self else { return }
            let result = await strongSelf.userUseCase.getUserList()
            switch result {
            case .success(let userList):
                strongSelf.userList.removeAll()
                strongSelf.userList.append(contentsOf: userList)
                strongSelf.dataSubject.onNext(())
            case .failure(let error):
                print(error)
            }
        }
    }
    
    func deleteUserList(id: Int) {
        Task(priority: .userInitiated) { [weak self] in
            guard let strongSelf = self else { return }
            let result = await strongSelf.userUseCase.deleteUserList(id: id)
            switch result {
            case .success(_):
               print("Deleted succesfully")
                strongSelf.getUserList()
            case .failure(let error):
                print(error)
            }
        }
    }
}
