//
//  UserDetailViewModel.swift
//  UserListing
//

import Foundation
import DomainKit
import DependancyKit
import RxSwift
import RxCocoa
import DomainKit

class UserDetailViewModel {
    private let userUseCase: UserInfoUseCase
    let dataSubject = PublishSubject<Void>()
    var user : User?
    var userId: Int?
  
    init(userUseCase: UserInfoUseCase = resolve()) {
        self.userUseCase = userUseCase
    }
    
    func getUserDetail() {
        Task(priority: .userInitiated) { [weak self] in
            guard let strongSelf = self else { return }
            let result = await strongSelf.userUseCase.getUserDetails(id: strongSelf.userId ?? 0)
            switch result {
            case .success(let userDetail):
                strongSelf.user = userDetail
                strongSelf.dataSubject.onNext(())
            case .failure(let error):
                print(error)
            }
        }
    }
    
    func updateUserDetail(name: String, email: String, id: Int, status: String, gender: String) {
        Task(priority: .userInitiated) { [weak self] in
            guard let strongSelf = self else { return }
            let result = await strongSelf.userUseCase.updateUserList(name: name, email: email, id: id, status: status, gender: gender)
            switch result {
            case .success(_):
                print("Successfully updated")
            case .failure(let error):
                print(error)
            }
        }
    }
}
