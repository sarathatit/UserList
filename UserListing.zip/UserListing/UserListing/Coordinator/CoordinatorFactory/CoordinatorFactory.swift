//
//  CoordinatorFactory.swift
//  UserListing

import Foundation
import UIKit

enum CoordinatorType {
    case userDetail
}

class CoordinatorFactory {
    static func create(with navigationController: UINavigationController,
                       withType type: CoordinatorType,
                       withValues data: Any? = nil) -> Coordinator {
        switch type {
        case .userDetail:
            return UserDetailViewCoordinator.init(navigationController: navigationController, id: data as? Int ?? 1)
            
        }
    }
}
