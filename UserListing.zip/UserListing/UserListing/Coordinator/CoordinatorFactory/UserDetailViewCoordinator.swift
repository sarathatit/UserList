//
//  UserDetailViewCoordinator.swift
//  UserListing
//

import Foundation
import UIKit

final class UserDetailViewCoordinator: Coordinator {
    
    // MARK: - Properties
    var navigationController: UINavigationController
    var userId: Int
    
    // MARK: - Init
    init(navigationController: UINavigationController, id: Int) {
        self.navigationController = navigationController
        self.userId = id
    }
    
    // MARK: - Routing
    func start(animated: Bool) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let userDetail: UserDetailViewController = storyboard.instantiateViewController(withIdentifier: "UserDetailViewController") as! UserDetailViewController
        userDetail.userDetailViewModel = UserDetailViewModel()
        userDetail.userDetailViewModel?.userId = userId
        self.navigationController.pushViewController(userDetail, animated: true)
    }
}

